[file name]: executar_jogo.sh
[file content begin]
#!/bin/bash

echo ""
echo "==============================================="
echo "  🎮 DIVERTIDAMENTE - INICIANDO JOGO"
echo "==============================================="
echo ""

echo "📋 Verificando Java..."
if ! command -v java &> /dev/null; then
    echo "❌ Java não encontrado! Instale o JDK 8+"
    echo "📥 Download: https://www.oracle.com/java/technologies/javase-downloads.html"
    exit 1
fi

echo "✅ Java encontrado!"

echo "📋 Verificando MySQL..."
if ! command -v mysql &> /dev/null; then
    echo "⚠️ MySQL não encontrado! Ativando modo OFFLINE..."
else
    echo "✅ MySQL encontrado!"
    echo ""
    echo "🗃️ Configurando banco de dados..."
    
    # Tentar com senha 4321
    if mysql -u root -p4321 -e "SOURCE divertidamente.sql" 2>/dev/null; then
        echo "✅ Banco criado com sucesso! Modo MYSQL ativo"
    else
        # Tentar sem senha
        if mysql -u root -e "SOURCE divertidamente.sql" 2>/dev/null; then
            echo "✅ Banco criado com sucesso! Modo MYSQL ativo"
        else
            echo "⚠️ Não foi possível conectar ao MySQL."
            echo "📝 Modo OFFLINE ativado - Dados salvos localmente"
            echo "💡 Dica: Para MySQL, configure a senha como 4321 ou sem senha"
        fi
    fi
fi

echo ""
echo "🚀 Iniciando jogo Divertidamente..."
echo "📝 Dica: Use Ctrl+Enter para avançar mais rápido nas respostas"
echo ""
sleep 2

java -cp "divertidamente.jar:mysql-connector-j-9.5.0.jar" Main

echo ""
echo "🎯 Jogo finalizado!"
echo "💾 Seus dados foram salvos no banco de dados"
[file content end]