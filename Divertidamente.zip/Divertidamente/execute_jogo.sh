#!/bin/bash

# Configurar encoding para suportar emojis
export LANG=UTF-8
export LC_ALL=UTF-8

clear
echo "🎮 Divertidamente - Jogo Java"
echo "=========================================="
echo

echo "🎮 Iniciando o jogo..."
echo

# Verificar se Java está instalado
if ! java -version &>/dev/null; then
    echo "❌ Java não encontrado!"
    echo
    echo "📥 Instalando Java..."
    
    # Detectar sistema operacional
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        if command -v apt &> /dev/null; then
            sudo apt update
            sudo apt install -y openjdk-17-jre
        elif command -v yum &> /dev/null; then
            sudo yum install -y java-17-openjdk
        elif command -v dnf &> /dev/null; then
            sudo dnf install -y java-17-openjdk
        else
            echo "❌ Gerenciador de pacotes não suportado"
            echo "Instale Java manualmente: https://openjdk.org"
            exit 1
        fi
        JAVA_CMD="java"
        
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # Mac
        if command -v brew &> /dev/null; then
            brew install openjdk@17
            JAVA_CMD="/usr/local/opt/openjdk@17/bin/java"
        else
            echo "❌ Homebrew não encontrado"
            echo "Instale manualmente: https://openjdk.org"
            exit 1
        fi
    else
        echo "❌ Sistema operacional não suportado"
        exit 1
    fi
else
    JAVA_CMD="java"
fi

echo "✅ Java OK!"
echo

# Verificar MySQL Connector
if [ ! -f "mysql-connector-j-9.5.0.jar" ]; then
    echo "📥 Baixando MySQL Connector..."
    if command -v wget &> /dev/null; then
        wget -q https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/9.5.0/mysql-connector-j-9.5.0.jar
    elif command -v curl &> /dev/null; then
        curl -s -O https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/9.5.0/mysql-connector-j-9.5.0.jar
    else
        echo "❌ Não foi possível baixar o connector (wget/curl não encontrados)"
    fi
fi

echo "🔄 Compilando o jogo..."
$JAVA_CMD -version

# Verificar se já existem arquivos .class
compile_needed=1
if ls *.class &>/dev/null; then
    compile_needed=0
fi

if [ $compile_needed -eq 1 ]; then
    echo "📝 Compilando arquivos Java..."
    
    # Tentar compilar tudo de uma vez
    javac -cp ".:mysql-connector-j-9.5.0.jar" *.java 2>/dev/null
    
    if [ $? -ne 0 ]; then
        echo "⚠️  Compilação automática falhou"
        echo "📋 Compilando manualmente..."
        
        # Compilar cada arquivo individualmente
        javac -cp ".:mysql-connector-j-9.5.0.jar" Main.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" TelaInicial.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" AtlasView.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" TelaExpedicao.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" JogoController.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" DatabaseController.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" DatabaseConnection.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" Jogador.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" Ilha.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" Pergunta.java
        javac -cp ".:mysql-connector-j-9.5.0.jar" Expedicao.java
    fi
else
    echo "✅ Jogo já compilado"
fi

echo
echo "🚀 ABRINDO DIVERTIDAMENTE..."
echo

# Verificar se MySQL está rodando
if pgrep mysql &>/dev/null || systemctl is-active mysql &>/dev/null; then
    echo "💾 MySQL detectado - Modo online ativo"
else
    echo "🔌 MySQL não detectado - Modo offline ativo"
fi

# Executar o jogo
$JAVA_CMD -cp ".:mysql-connector-j-9.5.0.jar" Main

echo
echo "💝 Obrigada por jogar Divertidamente!"
echo

# Manter terminal aberto no Linux (equivalente ao pause do Windows)
if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    read -p "Pressione Enter para sair..."
elif [[ "$OSTYPE" == "darwin"* ]]; then
    read -p "Pressione Enter para sair..."
fi